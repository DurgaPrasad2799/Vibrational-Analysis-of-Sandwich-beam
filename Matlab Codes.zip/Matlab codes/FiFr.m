clc;
clear;
syms bL
eqn=cos(bL)*cosh(bL)==-1;
bLi=[];
for i=1:1:13
    j=i+1;
    bl=vpasolve(eqn,bL,[i j]);
    bl=double(bl);
    bLi=[bLi,bl];
end
bLi

% Beam Properties 
L=0.18; % Length of sandWich Beam
E_Face=69e09; % Young's Modulus of Face Material 
E_Core=3.14e09; % Young's Modulus of Core Material 
b=0.025;
t_Face=0.003; % Thcikness of Face Material
t_Core=0.010; % Thcikness of Core Material 

I_Face=((b*t_Face^3)/12+b*t_Face*((t_Core+t_Face)/2)^2)*2;
I_Core=b*t_Core^3/12;
EI_eq=E_Core*I_Core+E_Face*I_Face;
disp(EI_eq);

A_Face=b*t_Face*2;
A_Core=b*t_Core;
f=2*t_Face/(t_Core+2*t_Face);
rho_Face=2700;
rho_Core=1560;
rho_eq_A_eq =(rho_Face*f*A_Face+rho_Core*(1-f)*A_Core);


%Natural Frequency in rad/sec
wn=(bLi).^2*sqrt((EI_eq)/(rho_eq_A_eq*L^4));
fn=wn/(2*pi); %in Hertz
wn
fn

% Mode shapes
% Base state
dx=0.01;
x=0:dx:L;
W0=zeros(1,(length(x)));
plot(x,W0,'k--');
hold on

%First Mode
bL=bLi(1);
W1=ModeShape (bL,dx,L);
plot(x,W1,'b','DisplayName','Mode-Shape 1');
hold on

%Second Mode
bL=bLi(2);
W2=ModeShape (bL,dx,L);
plot(x,W2,'r','DisplayName','Mode-Shape 2');
hold on

%Third Mode
bL=bLi(3);
W3=ModeShape (bL,dx,L);
plot(x,W3,'g','DisplayName','Mode-Shape 3');
hold on

%Fourth Mode
bL=bLi(4);
W4=ModeShape (bL,dx,L);
plot(x,W4,'m','DisplayName','Mode-Shape 4');
hold on
legend('show','location','northwest');

% Defining the Function for an Equation
function W=ModeShape (bL,dx,L)
b=bL/L;
C=cos(bL); S=sin(bL); Ch=cosh(bL); Sh=sinh(bL);
a=(C+Ch)/(S+Sh);
x=0:dx:L;
C=cos(b*x); S=sin(b*x); Ch=cosh(b*x); Sh=sinh(b*x);
W=(C-Ch)-a*(S-Sh);
end